# Sample SAML iOS application

This is a "bare bones" example of how to add SAML authentication to an iOS application using a web view.

Start by opening the `SAML Sample/OKWebViewController.m` file and following along with the comments in that file. 
