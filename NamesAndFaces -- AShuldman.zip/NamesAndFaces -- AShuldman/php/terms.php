<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Untitled Document</title>
</head>

<body>
<h3>By clicking “I Agree and Continue” I agree to:<br /></h3>
<ul>
	<li>Follow all rules outlined in the Hotchkiss AUP</li>
    <li>Refrain from screenshotting and sharing information posted in the app</li>
    <li>Refrain from sharing information with someone outside of the Hotchkiss community</li>
</ul>



</body>
</html>