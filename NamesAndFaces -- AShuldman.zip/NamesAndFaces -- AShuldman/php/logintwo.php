<?php

$hn = 'localhost';
$db = 'namesandfaces';
$un = 'namesandfaces';
$pw = 'W3bC0urse!';

?>
